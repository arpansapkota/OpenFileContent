package com.company;

import java.util.Scanner;

//Use OOP - Class and Object, Inheritance, Exception Handling, File Handling Concepts. (Don't use POP)
//Take directory name (eg: D:/New Folder) as Input from User
//List all files and folders of that directory
//Take filename (eg: a.txt) as Input from User
//If File exist in that directory then display the content of that file
//Else File not found Message

public class Main {

    public static void main(String[] args) {
        PrinterInterface printer = new Printer();

        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the Address where to search ");
        String address = scan.next();
        printer.listAll(address);

        System.out.println("Enter the file name");
        String fileName = scan.next();


        printer.printFile(address,fileName);

    }
}
